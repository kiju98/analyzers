# Measures the search time of English

export AUTH="-u elastic:elastic -HContent-Type:application/json"

echo multi-fields
num=0
time while (($num < 500))
do
curl $AUTH -XGET 'http://localhost:9200/test/_search' -d'
{
  "query": {
    "multi_match": {
      "query": "Olympic Games",
      "fields": [
        "text",
        "text.korean_field",
        "text.chinese_field",
        "text.japanese_field"
      ]
    }
  }
}' &> /dev/null
let num+=1
curl $AUTH -XGET 'http://localhost:9200/test/_search' -d'
{
  "query": {
    "multi_match": {
      "query": "올림픽대회",
      "fields": [
        "text",
        "text.korean_field",
        "text.chinese_field",
        "text.japanese_field"
      ]
    }
  }
}' &> /dev/null
let num+=1
curl $AUTH -XGET 'http://localhost:9200/test/_search' -d'
{
  "query": {
    "multi_match": {
      "query": "オリンピック大会",
      "fields": [
        "text",
        "text.korean_field",
        "text.chinese_field",
        "text.japanese_field"
      ]
    }
  }
}' &> /dev/null
let num+=1
curl $AUTH -XGET 'http://localhost:9200/test/_search' -d'
{
  "query": {
    "multi_match": {
      "query": "奥运会",
      "fields": [
        "text",
        "text.korean_field",
        "text.chinese_field",
        "text.japanese_field"
      ]
    }
  }
}' &> /dev/null
let num+=1
done

echo 
echo single field
num=0
time while (($num < 500))
do
curl $AUTH -XGET 'http://localhost:9200/mono/_search' -d'
{
  "query": {
    "multi_match": {
      "query": "Olympic Games",
      "fields": [
        "text"
      ]
    }
  }
}' &> /dev/null
let num+=1
curl $AUTH -XGET 'http://localhost:9200/mono/_search' -d'
{
  "query": {
    "multi_match": {
      "query": "올림픽대회",
      "fields": [
        "text"
      ]
    }
  }
}' &> /dev/null
let num+=1
curl $AUTH -XGET 'http://localhost:9200/mono/_search' -d'
{
  "query": {
    "multi_match": {
      "query": "オリンピック大会",
      "fields": [
        "text"
      ]
    }
  }
}' &> /dev/null
let num+=1
curl $AUTH -XGET 'http://localhost:9200/mono/_search' -d'
{
  "query": {
    "multi_match": {
      "query": "奥运会",
      "fields": [
        "text"
      ]
    }
  }
}' &> /dev/null
let num+=1
done

echo langdetect
num=0
time while (($num < 500))
do
curl $AUTH -XGET 'http://localhost:9200/test2/_search' -d'
{
  "query": {
    "multi_match": {
      "query": "Olympic Games",
      "fields": [
        "english_field",
        "korean_field",
        "chinese_field",
        "japanese_field"
      ]
    }
  }
}' &> /dev/null
let num+=1
curl $AUTH -XGET 'http://localhost:9200/test2/_search' -d'
{
  "query": {
    "multi_match": {
      "query": "올림픽대회",
      "fields": [
        "english_field",
        "korean_field",
        "chinese_field",
        "japanese_field"
      ]
    }
  }
}' &> /dev/null
let num+=1
curl $AUTH -XGET 'http://localhost:9200/test2/_search' -d'
{
  "query": {
    "multi_match": {
      "query": "オリンピック大会",
      "fields": [
        "english_field",
        "korean_field",
        "chinese_field",
        "japanese_field"
      ]
    }
  }
}' &> /dev/null
let num+=1
curl $AUTH -XGET 'http://localhost:9200/test2/_search' -d'
{
  "query": {
    "multi_match": {
      "query": "奥运会",
      "fields": [
        "english_field",
        "korean_field",
        "chinese_field",
        "japanese_field"
      ]
    }
  }
}' &> /dev/null
let num+=1
done

