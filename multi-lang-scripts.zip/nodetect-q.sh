# Measures the search time of English

echo multi-fields
num=0
time while (($num < 500))
do
curl -XGET 'http://localhost:9200/test/_search' -d'
{
  "query": {
    "multi_match": {
      "query": "Olympic Games",
      "fields": [
        "text",
        "text.korean_field",
        "text.chinese_field",
        "text.japanese_field"
      ]
    }
  }
}' &> /dev/null
let num+=1
done

echo 
echo single field
num=0
time while (($num < 500))
do
curl -XGET 'http://localhost:9200/mono/_search' -d'
{
  "query": {
    "multi_match": {
      "query": "Olympic Games",
      "fields": [
        "text"
      ]
    }
  }
}' &> /dev/null
let num+=1
done
